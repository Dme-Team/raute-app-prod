package com.raute.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
